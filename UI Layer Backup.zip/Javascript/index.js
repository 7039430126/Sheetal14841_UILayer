// const a =10;
// const b  = 20;
// console.log(b);

// function test()
// {
//     console.log(a);
//     console.log(b);
// }

//         console.log("Greetings from Javascript");
//         console.log(2+2);
// console.log("Hello from external JS file")


//Task1
// const myObject = {
//     key1:true,
//     key5:10,
// key3:"abc",
// key4:null,
// key10:NaN,
// }
// for(let key in myObject){
//     //console.log(key);
//     console.log(myObject[key]);
//     // if(key === "key1" || key === "key3")
//     // {
//     //     console.log(myObject[key])
//     // }
// }

//Task2
// const MIN = 1000;
// const MAX = 9999;
// const myNumber = [2536,5126,7356,3626,1233];
// let newRandomNumber;
// function getRandomNum(min,max){
//     min = Math.ceil(min);
//     max = Math.floor(max);
//     return Math.floor(Math.random() * (max - min + 1)) + min;

// }

// function isNotUnique(newRandomNumber)
// {
//     for(let number of myNumber)
//     {
//         if(number === newRandomNumber)
//         {
//             return true;
//         }
//     }
// }

// do {
//     newRandomNumber = getRandomNum(MIN,MAX);
// } while (isNotUnique(newRandomNumber));

// myNumber.unshift(newRandomNumber);
// console.log(myNumber);


//Task3

// const myObject = {
//     name: "Mike",
//     age: 30,
//     city: "London"
// };
// Object.prototype.country = "England";
// Object.prototype.tel = 01231234;

// for(let key in myObject)
// {
//     console.log("Name:"+myObject.name+"Age:"+myObject.age+"City:");
// }

//Events and events queue, call backs
// function waitingFn(timeInMs){
//     const futureTime = Date.now() + timeInMs;
//     while(futureTime > Date.now()){
//         //waiting
//     }
// }

// setTimeout(() => console.log("call back is executed"),3000)

// waitingFn(5000);
// console.log("function call has just ended");


// //--Callback function

// console.log("Last Statement in the global expression");


//closure

// function outerFn(mult)
// {
//     const a = 10;
//     function innerFn(b){
//         console.dir(innerFn);
//         return (a+b) * mult;
//     }
//     return innerFn;
// }


// const res1 = outerFn(2);
// console.log(res1(20)); //30

// const res2 = outerFn(3);
// console.log(res2(20)); //30

//challenge 1

// function sum(...args){
//  var total;
//  total = args.reduce((acc,elem) => acc + elem,0)
//  console.log(total);

// }

// sum(1,3);//4
// sum(5,10,30);//45
// sum(12,10,45,5);//72

//challenge 2 const

// const arr = [2,1];
// arr.push(3);
// console.log(arr);

// //challenge 3

// var i= 10;
// for(let i =0; i<5;i++)//instead var put let n check result
// {
// console.log(i);
// }
// console.log(i);//5

// //challenge 4

// var a = 5;
// b = 10;
// if(b>a){
//     let c = 2;
//     c = a + b + c;
//     console.log(c);
// }
// console.log(c);

//challenge 5

// function isNUmber(a){
//     if(typeof a === "number")
//     {return "Thats a number"}
//     else{return "thats not a number"}
// }
// console.log(isNUmber(10));

//challenge 6
// function mult(a,b){
//     return a * b;
// }

// setTimeout( () => {
//     console.log(mult(5,10));
// },2000);


// var  mult = (a,b) => a * b;

// setTimeout( () => {
//     console.log(mult(5,10));
// },2000);


// // challenge 7

// function multiplyBy(a,mult){
//     mult = mult !== undefined ? mult : 2;
//     console.log(a * mult);
// }

// multiplyBy(2);//4

// multiplyBy(2,undefined);//4

// multiplyBy(2,0);//0

// multiplyBy(5,10);//50

// multiplyBy(null);//0


// // challenge 8

// function missingArg(){
//     throw new Error("Function square required an args");
// }

// function square(a = missingArg()){
//     console.log(a*a);
// }
// square(10);//100
// square();//Nan

// // challenge 9

// var obj = {
//     x:5,
//     y:20,
//     z:3
// };

// function mult({x,y,z}){
//   return x * y * z;
// }

// console.log(mult(obj));

//challenge 10

// var a , b , c;
// var arr = [1,2,3,4,5,6,7];
// [a,b,...c] = arr;//rest operator
// console.log(a);

// console.log(b);

// console.log(c);

// // challenge 11 spread operator

// var a,b,c,d,arr;
// a = [1,2];
// b = [4,5];
// c = [8,9,10];
// d = [11];

// arr = [0,...a,3, ...b,6,7, ...c,d]
// console.log(arr);

// //challenge 12 copy array

// var a = [1,2,3,[4,5]];
// var b;
// //b=a;
// //b = a.slice();
// b = [...a];
// b.push("newElement");
// b[3].push(6)
// console.log(a);

// console.log(b);

// // challenge 13 template literals

// var cars = [
//     {brand:"honda",price:13000},
//     {brand:"rolls-royce",price:340000}
// ];

// function carInfo(car)
// {
//     var s;
//     if(car.price <=20000) s = "cheap";
//     else s = "expensive";
// return `Price of my new ${car.brand} \
// is ${car.price}$ and it is \
// ${s} car.`;
// }
// cars.forEach(car => console.log(carInfo(car)));

//challenge 14 swap

// var a = "first";
// var b = "second";
// console.log("Before Swap: "+a+"\n"+b);

// [b,a] = [a,b];

// console.log("After Swap: "+a+"\n"+b);

// //challenge 15 iterate object

// var nums = {
//     a:10,
//     b:20,
//     c:"string",
//     d:15
// };

// function sumofObjectValue(object){
//     var total = 0;
//     for(let k in object)
//     {
//         if(typeof object[k] === "number")
//         total += object[k];
//     }
//     return total;
// }

// console.log(sumofObjectValue(nums));

//challenge 16

// var nums = [10,-12,30,-1,-8,0,14,-33,20];

// function sumPlusMinus(arr){
//     return arr.reduce((acc,elem) => {
//         return{
//             plus: elem>0 ? acc.plus + elem: acc.plus,
//             minus: elem < 0 ? acc.minus + elem : acc.minus
//         }
//     },{plus:0,minus:0})
// }

// console.log(sumPlusMinus(nums));

var foo = {
    bar:function(){
        return this.baz;
    }, baz:1
};
(
    function (){
        return typeof arguments[0]();
    }

)
foo.bar();








































