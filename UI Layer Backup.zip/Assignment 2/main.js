var counter1 = 0;
function img1Click()
{

    console.log('Image clicked');
    counter1 = counter1 +1;
   
    let span1 = document.getElementById("span1");
   console.log(span1);
    span1.innerHTML = counter1;
    console.log(counter1);
   
}
var counter2 = 0;
function img2Click()
{

    console.log('Image clicked');
    counter2 = counter2 +1;
   
    let span2 = document.getElementById("span2");
   console.log(span2);
    span2.innerHTML = counter2;
    console.log(counter2);
   
}
var counter3 = 0;
function img3Click()
{

    console.log('Image clicked');
    counter3 = counter3 +1;
   
    let span3 = document.getElementById("span3");
   console.log(span3);
    span3.innerHTML = counter3;
    console.log(counter3);
   
}
var counter4 = 0;
function img4Click()
{

    console.log('Image clicked');
    counter4 = counter4 +1;
   
    let span4 = document.getElementById("span4");
   console.log(span4);
    span4.innerHTML = counter4;
    console.log(counter4);
   
}
var counter5 = 0;
function img5Click()
{
    
    console.log('Image clicked');
    counter5 = counter5 +1;
   
    let span5 = document.getElementById("span5");
   console.log(span5);
    span5.innerHTML = counter5;
    console.log(counter5);
   
}